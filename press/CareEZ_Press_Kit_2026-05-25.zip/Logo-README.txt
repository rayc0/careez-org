CAREEZ LOGO & BRAND ASSETS
───────────────────────────────────────────────────────────────────────────────

WORDMARK

  CareEZ  (Care + EZ)

  Typeface:    System sans-serif (Apple system font / Segoe UI / Helvetica)
  Weight:      900 (Black / Ultra-Bold)
  Colour:      "Care" — White (#FFFFFF)
               "EZ"   — Cyan (#00E5FF)
  Background:  Navy (#0A1428)

COLOUR PALETTE

  Primary navy:   #0A1428
  Navy mid:       #0E1C3A
  Navy dark:      #132046
  Cyan primary:   #00E5FF
  Cyan secondary: #29B6F6
  White:          #FFFFFF
  Gray:           #B0BEC5
  Yellow accent:  #FFD43B

LOGO USAGE RULES

  • Always use the wordmark on a dark (navy) or white background.
  • Do not stretch, skew, or recolour the logo.
  • The "EZ" component must always appear in #00E5FF cyan.
  • Minimum clear space: 0.5× the cap-height of the wordmark on all sides.
  • Do not place on a mid-tone or photographic background without a
    solid colour backing block.

ASSETS IN THIS PACKAGE

  Sample-Image.png    — CareEZ OG image (1200×630 px, RGB)
                        Safe for editorial use, feature thumbnails, social embeds.

ADDITIONAL ASSETS

  Full-resolution PNG and SVG wordmark files, product photography,
  and brand-kit files are available on request.

  Contact: hello@careez.org
  Brand page: https://careez.org/press/

───────────────────────────────────────────────────────────────────────────────
Carewells Limited · Hong Kong · careez.org
